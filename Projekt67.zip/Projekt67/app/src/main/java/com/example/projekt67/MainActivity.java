package com.example.projekt67;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerStadion, spinnerMecz;
    private EditText inputWiek;
    private Button btnKupBilet;
    private ImageView obrazek67;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerStadion = findViewById(R.id.spinnerStadion);
        spinnerMecz = findViewById(R.id.spinnerMecz);
        inputWiek = findViewById(R.id.inputWiek);
        btnKupBilet = findViewById(R.id.btnKupBilet);
        obrazek67 = findViewById(R.id.obrazek67);

        //  ukryty obrazek
        obrazek67.setVisibility(View.GONE);

        String[] stadiony = {
                "Stadion Narodowy (Warszawa)",
                "Polsat Plus Arena (Gdańsk)",
                "Stadion Miejski (Poznań)"
        };

        ArrayAdapter<String> adapterStadionout =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, stadiony);
        adapterStadionout.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStadion.setAdapter(adapterStadionout);

        spinnerStadion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String[] mecze;

                if (position == 0) {
                    mecze = new String[]{"Polska vs Niemcy", "Finał Pucharu Polski"};
                } else if (position == 1) {
                    mecze = new String[]{"Lechia Gdańsk vs Legia Warszawa", "Koncert Gwiazdy & Mecz Pokazowy"};
                } else {
                    mecze = new String[]{"Lech Poznań vs Raków Częstochowa", "Polska U21 vs Anglia U21"};
                }

                ArrayAdapter<String> adapterMeczow =
                        new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_item, mecze);
                adapterMeczow.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerMecz.setAdapter(adapterMeczow);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnKupBilet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String wiekTekst = inputWiek.getText().toString().trim();

                if (wiekTekst.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Błąd: Wpisz wiek kibica!", Toast.LENGTH_SHORT).show();
                    return;
                }

                int wiek = Integer.parseInt(wiekTekst);

                if (wiek <= 0 || wiek > 110) {
                    Toast.makeText(MainActivity.this, "Błąd: Podano nieprawidłowy wiek!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Pokaż obrazek jeśli wiek 67
                if (wiek == 67) {
                    obrazek67.setVisibility(View.VISIBLE);
                } else {
                    obrazek67.setVisibility(View.GONE);
                }

                String wybranyStadion = spinnerStadion.getSelectedItem().toString();
                String wybranyMecz = spinnerMecz.getSelectedItem().toString();
                String rodzajBiletu = (wiek < 18) ? "ULGOWY" : "NORMALNY";

                String komunikat = "Kupiono bilet " + rodzajBiletu +
                        "\nMecz: " + wybranyMecz +
                        "\nMiejsce: " + wybranyStadion;

                Toast.makeText(MainActivity.this, komunikat, Toast.LENGTH_LONG).show();
            }
        });
    }
}
